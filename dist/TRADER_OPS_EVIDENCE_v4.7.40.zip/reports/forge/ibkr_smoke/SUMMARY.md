# Portfolio Backtest Summary

## Overall Metrics

| Metric | Value |
|--------|-------|
| Total Return | 0.00% |
| Sharpe Ratio | 0.00 |
| Overall Max Drawdown | 0.00% |
| Profit Factor | 999.00 |
| Rebalance Events | 120 |
| Trade Count | 0 |
| Total Bars | 360 |
| Worst 1-Day | 0.0000% |
| DD Peak→Trough | 2026-01-12 08:30:00-06:00 → 2026-01-12 08:30:00-06:00 |
| Exposure Cap Events | 0 |

## Benchmark Comparison (Equal-Weight B&H)

| Metric | Value |
|--------|-------|
| Benchmark Return | 0.03% |
| Benchmark Sharpe | 0.19 |
| Benchmark Max DD | -1.41% |
| Excess Return | -0.03% |
| Tracking Error | 0.0926 |
| Information Ratio | -0.19 |
| Max DD Diff | 1.41% |

## Safety State Distribution

| State | Bars |
|-------|------|
| NORMAL | 360 |

## Per-Regime Performance

| Regime | Bars | Return | Sharpe | DD (Global) | DD (Segment) |
|--------|------|--------|--------|-------------|--------------|
| RANGE_HIGH_VOL | 12 | 0.00% | 0.00 | 0.00% | 0.00% |
| RANGE_LOW_VOL | 36 | 0.00% | 0.00 | 0.00% | 0.00% |
| TREND_HIGH_VOL | 120 | 0.00% | 0.00 | 0.00% | 0.00% |
| TREND_LOW_VOL | 159 | 0.00% | 0.00 | 0.00% | 0.00% |
